import page from '../../node_modules/page/page.mjs';

export function goTo(path) {
    page.redirect(path);
}